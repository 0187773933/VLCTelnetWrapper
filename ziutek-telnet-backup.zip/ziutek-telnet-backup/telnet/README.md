[documentation](http://godoc.org/github.com/ziutek/telnet)
